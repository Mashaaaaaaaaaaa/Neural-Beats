<?php
   class BP_PHP{
       private static $instanca=null;
       
       private function __construct() {}
       
       private function __clone() {}

      public static function getInstanca() {
        if (!isset(self::$instanca)) {
            $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
            self::$instanca = new PDO('mysql:host=localhost;dbname=neural beats', 'root', '', $pdo_options);
        }
        return self::$instanca;
    }
   }

?>
