<?php
    class Poruka{
        private $idPoruke;
        private $posiljalac;
        private $sadrzaj;
        private $vreme;
        private $tip;
        
        public function __get($placeholder){
            return  $this->$placeholder;
        }
        
        public function __construct($idPoruke, $posiljalac, $sadrzaj, $vreme, $tip) {
            $this->posiljalac = $posiljalac;
            $this->sadrzaj = $sadrzaj;
            $this->vreme = $vreme;
            $this->tip=$tip;
            $this->idPoruke=$idPoruke;
        }
        
        public static function sacuvajPoruku($poruka){
            $konekcija= BP_PHP::getInstanca();
            $unos=$konekcija->prepare("INSERT INTO Korisinik ( idPoruke, Posiljalac, Sadrzaj, Vreme) VALUES (:idPoruke, :Posiljalac, :sadrzaj, :vreme)");
            $unos->execute(array('idPoruke' => $poruka["idPoruke"],"Posiljalac"=>$poruka["posiljalac"],"Sadrzaj"=>$poruka["Sadrzaj"],"Vreme"=>$poruka["Vreme"]));
        }
        
         public static function obrisiPoruku($id){
            $konekcija= BP_PHP::getInstanca();
            $username=$korisnik->get("username");
            $brisanje="DELETE FROM Poruka WHERE idPoruke='$idPoruke'";
            $konekcija->query($brisanje);
        }
        
        public static function dohvatiSadrzajPoruke($id){
            $konekcija = BP_PHP::getInstanca();
            $upit = $konekcija->query("SELECT Sadrzaj FROM Poruka WHERE idPoruke='id'");
            $upit = $rezultat->fetch();
            if ($korisnik == NULL) {
                return FALSE;
            }
            else {
                return korisnik["Sadrzaj"];
            }
        }
    }
?>

