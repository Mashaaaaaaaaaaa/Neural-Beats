<?php

    class Komentar{
        private $idKomentara;
        private $zaMuziku;
    
        public function __get($placeholder) {
            return  $this->$placeholder;
        }

        public function __construct($zaMuziku, $idKomentara) {
            $this->zaMuziku = $zaMuziku;
            $this->idKomentara=$idKomentara;
        }
        
        public static function sacuvajKomentar($komentar){
            $id=$komentar->idKomentara;
            $muzika = $komentar->zaMuziku;
            $konekcija = BP_PHP::getInstanca();
            $unos = $konekcija->prepare("INSERT INTO Komentar (zaMuziku, idKomentara) VALUES (:zaMuziku, :idKomentara)");
            $inos->execute(array('zaMuziku' => $muzika,"idKomentara"=> $id)); 
        }
        
        public static function obrisiKomentar($komentar){
           $id=$komentar->idKomentara;
           $konekcija = BP_PHP::getInstanca();
           $brisanje="DELETE FROM Komentar WHERE idKomentara = '$id'";
           $konekcija->query($brisanje);  
           Poruka::obrisi_poruku($id);
        }
        
        public static function dohvatiKomentareKorisnika($korisnik){
            $id=$korisnik->idKorisnika;
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT Poruka.* FROM Korisnik,Komentar,Poruka WHERE Komentar.idKomentara = Poruka.idPoruke AND Korisnik.idKorisnika='$id' ORDER BY Vreme");
            $niz=[];
            foreach($rezultat->fetchAll() as $poruka){
                $niz[] = new Poruka($poruka["idPoruke"], $poruka["posiljalac"], $poruka["sadrzaj"], $poruka["vreme"], "komentar");
            }
            return niz[];
             
        }
        
        public static function dohvatiKomentareZaMuziku($muzika){
            $id=$muzika->idMuzike;
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT Poruka.* FROM Muzka,Komentar,Poruka WHERE Komentar.idKomentara = Poruka.idPoruke AND Komentar.zaMuziku='$id'  ORDER BY Vreme");
            $niz=[];
            foreach($rezultat->fetchAll() as $poruka){
                 $niz[] = new Poruka($poruka["idPoruke"], $poruka["posiljalac"], $poruka["sadrzaj"], $poruka["vreme"], "komentar");
            }
            return niz[];
        }
        
        
    }
