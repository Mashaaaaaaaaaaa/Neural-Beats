<?php
    
    class Korisnik{
        private $idKorisnika;
        private $password_hash;
        private $username;
        private $email;
        private $admin;
        private $opis;
        
        public function __get($placeholder){
            return $this->$placeholder;
        }
        
        public function __construct($password_hash, $username, $email, $admin, $opis) {
            $this->password_hash = $password_hash;
            $this->username = $username;
            $this->email = $email;
            $this->admin = $admin;
            $this->opis = $opis;
        }
        
        public static function dohvatiKorisnika($username){
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT * FROM Korisnik WHERE Username='$username'");
            $korisnik = $rezultat->fetch();
            if($korisnik==NULL){
               return NULL; 
            }
            else{
                return new Korisnik($korisnik["idKorisnika"], $korisnik["password_hash"],korissnik["username"],$korisnik["admin"], $korisnik["opis"]);
            }
        }
        
        public function daLiJeAdmin(){
            if ($this->admin & 1) {
             return TRUE;
            } 
            else {
                   return FALSE;
            }
        }
        
        public function proveriPassword($password_hash){
            if( $this->password_hash == $pasword_hash){
                return TRUE;
            }
            else{
                return FALSE;
            }
        }
        
         public static function dohvatiSveKorisnike(){
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT * FROM Korisnik");
            $niz=[];
            foreach($rezultat->fetchAll() as $korisnik){
                $niz[] = new Korisnik($korisnik["idKorisnika"], $korisnik["password_hash"], $korisnik["username"],$korisnik["admin"], $korisnik["opis"]);
            }
            return niz[];
        }
        
        public static function sacuvajKorisnika($korisnik){
            $konekcija= BP_PHP::getInstanca();
            $unos=$konekcija->prepare("INSERT INTO Korisinik (password_hash, username, email, admin, opis) VALUES (:pasword_hash, :username, :email, :admin, :opis)");
            $unos->execute(array('password_hashe' => $korisnik["password_hashe"],"username"=>$korisnik["username"],"email"=>$korisnik["email"],"admin"=>$korisnik["admin"],"opis"=>$korisnik["opis"]));     
        }
        
        public static function ukloniKorisnika($korisnik){
            $konekcija= BP_PHP::getInstanca();
            $username=$korisnik->get("username");
            $brisanje="DELETE FROM Korisnik WHERE Username='$username'";
            $konekcija->query($brisanje);
        }
        
        public static function izmenaKorisnika($korisnik){
            $konekcija= BP_PHP::getInstanca();
            if($korisnik->__get("idKorisnika")!=NULL){
                $password_hash = $korisnik->__get();
                $username = $korisnik->__get();
                $email = $korisnik->__get();
                $admin = $korisnik->__get();
                $opis = $korisnik->__get();
                $izmena="UPDATE Korisnik SET Pasword_hash='$password_hash' Username='$username' Email='$email' Admin='$admin' Opis='$opis' ";
                $konekcija->query($izmena);
            }
            
        }
    }   
    
?>

