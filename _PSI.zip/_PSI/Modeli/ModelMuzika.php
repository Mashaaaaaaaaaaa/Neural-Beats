<?php
    class Muzika{
        private $idMuzike;
        private $autor;
        private $naslov;
        private $opis;
        private $vreme;
        
        public function __get($placeholder) {
            return $this->$placeholder;
        }
        
        public function __construct($idMuzike, $autor, $naslov, $opis, $vreme) {
            $this->autor = $autor;
            $this->naslov = $naslov;
            $this->opis = $opis;
            $this->vreme = $vreme;
        }
        
        public static function  dohvatiMuzikuPoNaslovu($naslov){
            $konekcija = BP_PHP::getInstanca();
            $upit = $konekcija->query("SELECT * FROM Muzika WHERE Naslov='$naslov' ORDER BY Vreme");
            $nizMuz=[];
            return nizMuz[];
        }
        
        public static function  dohvatiMuzikuPoAutoru($autor){
            $konekcija = BP_PHP::getInstanca();
            $idAutora = $autor->idKorisnika;
            $upit = $konekcija->query("SELECT * FROM Muzika WHERE Autor='$idAutora' ORDER BY Vreme");
            $nizMuz=[];
            foreach ($upit->fetchAll() as $muzika){
                $nizMuz[] = new Muzika($muzika["idMuzike"], $muzika["Autor"], $muzika["Naslov"], $muzika["Opis"], $muzika["Vreme"]);
            }
            return nizMuz[];
        }
        
        public static function  dohvatiMuzikuPoOpisu($opis){
            $konekcija = BP_PHP::getInstanca();
            $upit = $konekcija->query("SELECT * FROM Muzika WHERE Autor='$nopis' ORDER BY Vreme");
            $nizMuz=[];
            foreach ($upit->fetchAll() as $muzika){
                $nizMuz[] = new Muzika($muzika["idMuzike"], $muzika["Autor"], $muzika["Naslov"], $muzika["Opis"], $muzika["Vreme"]);
            }
        }
        
        public static function  dohvatiSpecificnuMuziku($autor, $naslov){
            $konekcija = BP_PHP::getInstanca();
            $upit = $konekcija->query("SELECT * FROM Muzika WHERE Autor='$autor' AND Naslov='$naslov'");
            $rezutat=$upit->fetch();
            if ($rezultat != NULL) {
                return new Muzika($rezultat['idMuzike'], $rezultat['autor'], $rezultat['naslov'], $rezultat['opis'], $rezultat['vreme']);
            }
            else {
                return NULL;
            } 
        }
    }
?>

