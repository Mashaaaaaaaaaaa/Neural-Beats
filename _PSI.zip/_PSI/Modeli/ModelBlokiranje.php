<?php
    
    class Blokiranje{
        private $blokirao;
        private $blokiran;
        
        public function __get($placeholder){
            return $this->$placeholder;
        }
        
        public function __construct($blokirao, $blokiran) {
            $this->blokirao = $blokirao;
            $this->blokiran = $blokiran;
        }
           
        public static function daLiImaBlokiranja($blokirao, $blokiran){
            $blokiranID=$blokiran->$idKorisnika;
            $blokiraoID=$blokirao->$idKorisnika;
            $konekcija= BP_PHP::getInstanca();
            $upit=$konekcija->query("SELECT * WHERE Blokiran='$blokiranID' AND Blokirao='$blokiraoID'");
            $uslov=$upit->fetch();
            if (uslov != NULL) {
                return TRUE;
            } 
            else {
                return FALSE;
            }
    }
        
        public static function dodajBlokiranje($blokira,$blokiran){
            if(Blokiranje::da_li_ima_blokiranja($blokira, $blokiran)!=TRUE){
                $konekcija= BP_PHP::getInstanca();
                $blokiranID=$blokiran->$idKorisnika;
                $blokiraoID=$blokira->$idKorisnika;
                $unos = $konekcija->prepare( "INSERT INTO Blokiranje (Bloirao, Blokiran) VALUES (:Blokirao, :Blokiran)");
                $unos->execute(array("Blokirao" => $blokiraoID,"Blokiran"=> $blokiranID));  
            }
        }
        public static function ukoniBlokirao($blokirao, $blokiran){
            $konekcija= BP_PHP::getInstanca();
            $blokiraoID=$blokirao->$idKorisnika;
            $blokiranID=$blokiran->$idKorisnika;
            $brisanje = "DELETE FROM Blokiranje WHERE Blokirao='$blokiraoID' AND Blokiran='$blokiranID'";
            $konekcija->query($brisanje);
        }
    }
?>