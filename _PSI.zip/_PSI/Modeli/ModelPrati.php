<?php

    class Prati{
        private $Prati;
        private $Pracen;
    
        public function __get($placeholder){
            return  $this->$placeholder;
        }
        
        public function __construct($Prati, $Pracen) {
            $this->Prati = $Prati;
            $this->Pracen = $Pracen;
        }
        public static function dohvatiSvePratioce($username){
            $konekcija= BP_PHP::getInstanca();
            $korisnik = Korisnik::dohvati_korisnika($username);
            $id=$korisnik->idKorisnika;
            $upit=$konekcija->query("SELECT Korisnik.* FROM Korisnik, Prati WHERE Korisnik.idKorisnika = Prati.Prati AND Prati.Pracen='$id'");
            $niz=[];
            foreach($upit->fetchALL() as $korisnik){
                 $niz[] = new Korisnik($korisnik["password_hash"],korissnik["username"],$korisnik["admin"], $korisnik["opis"]);
            }
        }
        public static function dohvatiSveKojePrati($username){
            $konekcija= BP_PHP::getInstanca();
            $korisnik = Korisnik::dohvati_korisnika($username);
            $id=$korisnik->idKorisnika;
            $upit=$konekcija->query("SELECT Korisnik.* FROM Korisnik, Prati WHERE Korisnik.idKorisnika = Prati.Pracen AND Prati.Prati='$id'");
            $niz=[];
            foreach($upit->fetchALL() as $korisnik){
                 $niz[] = new Korisnik($korisnik["password_hash"],korissnik["username"],$korisnik["admin"], $korisnik["opis"]);
            }
        }
        public static function ukoniPracenje($korisnik_prati, $korisnik_pracen){
            $konekcija= BP_PHP::getInstanca();
            $id_prati=$korisnik_prati->$idKorisnika;
            $id_pracen=$korisnik_pracen->$idKorisnika;
            $brisanje = "DELETE FROM Prati WHERE Prati='$id_prati' AND Pracen='$id_pracen'";
            $konekcija->query($brisanje);
            
        }
        public static function dodajPracenje( $korisnik_prati, $korisnik_pracen){
            $konekcija= BP_PHP::getInstanca();
            $id_prati=$korisnik_prati-$idKorinsika;
            $id_pracen=$korisnik_pracen->$idKorisnika;
            $unos = $konekcija->prepare( "INSERT INTO Prati (Prati, Pracen) VALUES (:Prati, :Pracen)");
            $unos->execute(array("Prati" => $id_prati,"Pracen"=> $id_pracen));
        }
        
        public static function daLiPrati($prati, $pracen){
            $konekcija= BP_PHP::getInstanca();
            $idPrati=$prati->$idKorisnika;
            $idPracen=$pracen->$idKorisnika;
            $upit =  $konekcija->query("SELECT * FROM Prati Where Prati='$idPrati' AND Prati='$idPracen' ");
            $rezultat= $upit->fetch();
            if ($rezultat != NULL) {
              return TRUE;
            }
            else {
                return FALSE;
            }
        }
    }
?>

