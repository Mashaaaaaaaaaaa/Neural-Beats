<?php
    
    class Licna_Poruka{
        private $idLicnePoruke;
        private $Primalac;
       
        public function __get($placeholder){
            return  $this->$placeholder;
        }
        
        public function __set($name, $value) {
            if(property_exists(Licna_Poruka, $name)){
                $this->name=$value;
            }
        }
        
        public function __construct($idLicnePoruke, $Primalac) {
            $this->idLicnePoruke = $idLicnePoruke;
            $this->Primalac = $Primalac;
        }

        public static function sacuvajLicnuPoruku($licnaporuka){
            $idLP = $licnaporuka->$idLicnePoruke;
            $posiljalac= $licnaporuka->$Primalac;
            $konekcija= BP_PHP::getInstanca();
            $unos = $konekcija->prepare( "INSERT INTO Licna_Poruka (idLicnePoruke, Primalac) VALUES (:idLicnePOruke, :Primalac)");
            $unos->execute(array("idLicnePoruke" =>  $idLP,"Primalac"=> $posiljalac ));
        }
        
        public static function dohvatiLicnePorukezaKorisnika($korisnik){
            $id=$korisnik->idKorisnika;
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT Poruka.* FROM Korisnik,Komentar,Poruka WHERE Licna_poruka.idLicne_Poruke = Poruka.idPoruke AND Korisnik.idKorisnika='$id' ORDER BY Vreme ");
            $niz=[];
            foreach($rezultat->fetchAll() as $poruka){
            $niz[] = new Poruka($poruka["idPoruke"], $poruka["posiljalac"], $poruka["sadrzaj"], $poruka["vreme"], "licna_poruka");
            }
            return niz[];  
        }
        
        public static function dohvatiLicnePorukeodKorisnika($korisnik){
            $id=$korisnik->idKorisnika;
            $konekcija = BP_PHP::getInstanca();
            $rezultat = $konekcija->query("SELECT Poruka.* FROM Korisnik,Licna_poruka,Poruka WHERE Licna_poruka.idLicne_Poruke = Poruka.idPoruke AND Korisnik.idKorisnika='$id' ORDER BY Vreme");
            $niz=[];
            foreach($rezultat->fetchAll() as $poruka){
            $niz[] = new Poruka($poruka["idPoruke"], $poruka["posiljalac"], $poruka["sadrzaj"], $poruka["vreme"], "licna_poruka");
            }
            return niz[];
        }
        
        public static function obrisiLicnuPoruku(){
           $id=$komentar->idKomentara;
           $konekcija = BP_PHP::getInstanca();
           $brisanje="DELETE FROM LicnaPoruka WHERE idLicnePoruke = '$id'";
           $konekcija->query($upit);  
           Poruka::obrisi_poruku($id);
        }
    }



