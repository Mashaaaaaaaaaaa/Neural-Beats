#include "MidiFile.h"
#include "Options.h"
#include <iostream>
#include <iomanip>
//#include <filesystem>
#include <fstream>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <cstdlib>

using namespace std;
using namespace smf;

int main(int argc, char** argv) {
	Options options;
	options.process(argc, argv);
	string path=options.getArg(1);
	//if (options.getArgCount() > 0) midifile.read(options.getArg(1));
	//else midifile.read(cin);
	DIR *dp;
	struct dirent *dirp;
	if((dp  = opendir(path.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << path << endl;
        return errno;
    }
	
	while ((dirp = readdir(dp)) != NULL){
		string basepath=path+"/"+(string)dirp->d_name;
		if(basepath.substr(basepath.find_last_of(".") + 1)!="mid") continue;
		MidiFile midifile;
		//string basepath=(string)entry.path();
		midifile.read(basepath);
		int tpq=midifile.getTicksPerQuarterNote();
		//cout << "TPQ: " << midifile.getTicksPerQuarterNote() << endl;
	    //cout << "TRACKS: " << midifile.getTrackCount() << endl;
	    midifile.joinTracks();
		midifile.linkNotePairs();
		midifile.doTimeAnalysis();
	    // midifile.getTrackCount() will now return "1", but original
	    // track assignments can be seen in .track field of MidiEvent.
	    //cout << "TICK    DELTA   TRACK   MIDI MESSAGE\n";
	    //cout << "____________________________________\n";
	    MidiEvent* mev;
	    //int deltatick;
		int filecount=0;
		ofstream fout;
		//create_directory(basepath+" split");
		string t_str="mkdir \"splits/"+(string)dirp->d_name+" split\"";
		const int dir_err = system(t_str.c_str());
		if (-1 == dir_err)
		{
    		cout<<"Error creating directory!\n";
		    break;
		}
		fout.open("splits/"+(string)dirp->d_name+" split/"+to_string(filecount));
	    for (int event=0; event < midifile[0].size(); event++) {
			mev = &midifile[0][event];
			if(!mev->isNoteOn()) continue;
			if(mev->tick*120/tpq-1920*filecount>1920){
				filecount++;
				fout.close();
				fout.open("splits/"+(string)dirp->d_name+" split/"+to_string(filecount));
			}
			//if (event == 0) deltatick = mev->tick;
			//else deltatick = mev->tick - midifile[0][event-1].tick;
			fout << dec << mev->tick*120/tpq-1920*filecount;
			//cout << '\t' << deltatick;
			fout << "," << mev->track;
			fout << "," << int(mev->getDurationInSeconds()*240);
			fout << "," << hex;
	 		for (int i=1; i < mev->size(); i++)
				fout << (int)(*mev)[i] << ' ';
	 	    fout << endl;
	    }
    }
	return 0;
}
